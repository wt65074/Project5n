public class xor {
    public static void main(String[] args) {
        System.out.println("Pos 1: " + (4));
        System.out.println("Pos 2: " + (4 ^ 15));
        System.out.println("3, 20 = " + ((4 ^ 15)^15));
        System.out.println("3, 20 = " + (((4 ^ 15)^15)^15));
    }
}