// Will Tobey
// wtobey1@jhu.edu
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Random;
import java.util.List;

/**
 * Hash Table implementation that performs basic operations
 * in O(1) by way of a Cukoo hash table.
 *
 * @param <K> The key type.
 * @param <V> The value type.
*/
public class HashMap<K, V> implements Map<K, V> {

    static final double MAX_LOAD_FACTOR = 0.5;
    static final int INITIAL_SIZE = 16;
    private int maxDisplacements = 0;

    private int count = 0;

    public int rehashes = 0;

    // Hash functions
    public HashFunction hashOne;
    public HashFunction hashTwo;

    // Table
    private Entry<K, V>[] table;


    // Entry pairs up a key and a value.
    private static class Entry<K, V> {
        K key;
        V value;

        Entry(K k, V v) {
            this.key = k;
            this.value = v;
        }

        @Override
        public String toString() {
            return this.key + ": " + this.value;
        } 

    }

    public HashMap() {

        table = (Entry<K, V>[]) new Entry[INITIAL_SIZE];

        this.hashOne = this.newPowerHashFunction(INITIAL_SIZE);
        this.hashTwo = this.newPowerHashFunction(INITIAL_SIZE);

        this.updateMaxDisplacements(INITIAL_SIZE);

    }

    private double loadFactor() {
        //System.out.println("Calculating Load Factor: " + this.count + "/" + this.table.length);
        return (double) this.count / (double) this.table.length;
    }

    private int hash(Entry<K, V> e, HashFunction f) {
        return this.hash(e.key, f);
    }

    public int hash(K key, HashFunction f) {
        return f.hash(key.hashCode());
    }

    public HashFunction newPrimeHashFunction(int size) {
        return UniversalHashes.prime(size);
    }

    private HashFunction newPowerHashFunction(int size) {
        return UniversalHashes.power(size);
    }

    private void updateMaxDisplacements(int size) {

        int max = (int) (Math.log(size) / Math.log(2));

        // Source
        maxDisplacements = max > 2 ? max : 2;

    }

    private void insert(Entry<K, V> e) {

        if (this.loadFactor() >= MAX_LOAD_FACTOR) {

            //System.out.println("Executing Planned Rehash");

            this.rehash(this.table.length * 2);

        }

        Entry<K, V> current = place(e);
        
        while (current != null) {

            //System.out.println("Place Failed, displaced: " + current);

            // Im doing this because it is silly to rehash right before we are going to rehash again
            if (this.loadFactor() >= MAX_LOAD_FACTOR - 0.05) {
                rehash(this.table.length * 2);
            } else {
                rehash(this.table.length * 2);
            }
            

            current = place(current);

        }

        this.count++;

    }

    private void rehash(int size) {

        rehashes++;

        //System.out.println("Begining Rehash, Size: " + size + "---------------------------------");
        //System.out.println("Load Factor: " + this.loadFactor());

        // Create new table
        Entry<K, V>[] temp = this.table;

        /*
        There is no need to allocate new tables for the rehashing: We may simply run through the tables to delete and perform the usual insertion procedure on all keys found not to be at their intended position in the table.

        — Pagh & Rodler, "Cuckoo Hashing"[1]
        */

        // Create new hashing functions
        this.hashOne = this.newPowerHashFunction(size);
        this.hashTwo = this.newPowerHashFunction(size);

        this.table = (Entry<K, V>[]) new Entry[size];

        this.updateMaxDisplacements(size);

        // Empty table
        for (Entry<K, V> e: temp) {
            if (this.place(e) != null) {
                //System.out.println("Rehash Failed");
                this.table = temp;
                this.rehash(size);
                return;
            }

        }

        //System.out.println("Rehash Succeeded ---------------------------------");

    }

    private V removeKey(K k) {

        int hash1 = this.hash(k, this.hashOne);

        Entry<K, V> foundH1 = table[hash1];

        if (foundH1 != null && foundH1.key.equals(k)) {

            table[hash1] = null;

            return foundH1.value;

        }

        int hash2 = this.hash(k, this.hashTwo);

        Entry<K, V> foundH2 = table[hash2];

        if (foundH2 != null && foundH2.key.equals(k)) {

            table[hash2] = null;

            return foundH2.value;

        }

        return null;

    }

    private Entry<K, V> place(Entry<K, V> e) {

        if (e == null) { return null; }

        //System.out.println("Placing: " + e + " with hashes: { " + hash(e, hashOne) + ", " + hash(e, hashTwo) + "}");
        //System.out.println("Into: " + this);

        HashFunction func = this.hashOne;

        Entry<K, V> current = e;

        int displacements = 0;

        while (displacements++ < this.maxDisplacements) {

            int position = hash(current, func);

            //System.out.println("Placing at position: " + position + " Options: {" + hash(current, hashOne) + ", " + hash(current, hashTwo) + "}");

            Entry<K, V> temp = table[position];
            table[position] = current;

            if (temp == null) {
                return null;
            }

            //System.out.println("Displaced: " + temp.key);

            current = temp;

            //System.out.println("Displacements: " + displacements);
            if (hash(temp, this.hashOne) == position) {
                func = this.hashTwo;
            } else {
                func = this.hashOne;
            }

        }

        //System.out.println("Need Rehash. Could not place: " + e);

        return current;

    }

    private Entry<K, V> find(K k) {

        int hash1 = this.hash(k, this.hashOne);

        Entry<K, V> foundH1 = table[hash1];

        if (foundH1 != null && foundH1.key.equals(k)) {
            return foundH1;
        }

        int hash2 = this.hash(k, this.hashTwo);

        Entry<K, V> foundH2 = table[hash2];

        if (foundH2 != null && foundH2.key.equals(k)) {
            return foundH2;
        }

        return null;

    }

    @Override
    public void insert(K k, V v) throws IllegalArgumentException {

        if (this.find(k) != null) {
            throw new IllegalArgumentException();
        }

        Entry<K, V> newEntry = new Entry<K, V>(k, v);
        this.insert(newEntry);

    }

    @Override
    public V remove(K k) throws IllegalArgumentException {
        
        V removed = this.removeKey(k);

        if (removed == null) {
            throw new IllegalArgumentException();
        }

        return removed;

    }

    @Override
    public void put(K k, V v) throws IllegalArgumentException {

        Entry<K, V> e = this.find(k);

        if (e == null) {
            throw new IllegalArgumentException();
        }

        e.value = v;

    }

    @Override
    public V get(K k) throws IllegalArgumentException {

        Entry<K, V> e = this.find(k);

        if (e == null) {
            throw new IllegalArgumentException();
        }

        return e.value;

    }

    @Override
    public boolean has(K k) {

        Entry<K, V> e = this.find(k);

        return e != null;

    }

    @Override
    public int size() {

        return this.count;

    }

    @Override
    public String toString() {

        StringBuilder s = new StringBuilder();
        s.append("{");
        for (int i = 0; i < this.table.length; i++) {
            Entry<K, V> e = this.table[i];
            if (e == null) { continue; }
            s.append("" + e.key + ": " + e.value);
            //s.append(" (" + this.hash(e, this.hashOne) + ", " + this.hash(e, this.hashTwo) + ")"); // REMOVE
            if (i < this.table.length - 1) {
                s.append(", ");
            }
        }
        s.append("}");
        return s.toString();

    }

    @Override
    public Iterator<K> iterator() {

        List<K> keys = new ArrayList<K>();
        for (Entry<K,V> e: this.table) {
            if (e != null) {
                keys.add(e.key);
            }
            
        }

        return keys.iterator();

    }

    public static void main(String[] args) {

        
        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
        Random r = new Random();

        for (int i = 0; i < 200; i++) {

            try {

                map.insert(i, 0);
                System.out.println("Has: " + map.has(i));
            } catch (IllegalArgumentException e) {

                
            }

        }

        for (int i = 0; i < 200; i++) {

            try {
                map.remove(i);
                System.out.println("Has: " + map.has(i));
            } catch (IllegalArgumentException e) {

            }


        }

        
        
     }


}